package practice10;

public class OddEx {
	public static void main(String[] args) {
		Odd odd = new Odd(10);
		System.out.println(odd.isOdd());
	}
}
