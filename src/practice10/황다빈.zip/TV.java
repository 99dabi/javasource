package practice10;

public class TV {
	private int size;
	public TV(int size) {
		super();
		this.size=size;
	}
	protected int getSize() {
		return size;
	}
}
