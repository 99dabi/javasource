package practice10;

public class ConverterEx {

	public static void main(String[] args) {
		Converter converter = new Won2Dollar();
		converter.run();

	}

}
