package practice10;

public class Odd extends OddDetector{
	

	public Odd(int odd) {
		super(odd);
	}
	
	@Override
	public boolean isOdd() {
		
		return super.isOdd();
	}
}
